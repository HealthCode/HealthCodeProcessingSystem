package org.healthCode.TestMongoDBCuncurrency;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;


import com.mongodb.DB;

import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;


public class InsertFileUsingGridFsInMongoDb {
	
	InsertFileUsingGridFsInMongoDb() {}
	
	public int SaveDocument() {

		try {

			@SuppressWarnings("deprecation")
			Mongo mongo = new Mongo("localhost", 27017);
			@SuppressWarnings("deprecation")
			DB db = mongo.getDB("gridfs");
									
			// create a "photo" namespace
			GridFS gfsPhoto = new GridFS(db, "collection_gridfs");

			// get image file from local drive
			InputStream in = new FileInputStream(new File("e:\\proj_main\\TestMongoConc\\Pic1.jpg"));
			GridFSInputFile gfsFile = gfsPhoto.createFile(in,true);

			// save the image file into mongoDB
			gfsFile.save();

		} catch (MongoException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;

	}
}