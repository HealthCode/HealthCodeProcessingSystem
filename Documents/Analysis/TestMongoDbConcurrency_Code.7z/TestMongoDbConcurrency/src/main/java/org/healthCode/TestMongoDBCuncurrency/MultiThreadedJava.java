package org.healthCode.TestMongoDBCuncurrency;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;


public class MultiThreadedJava implements Runnable {

	public Thread t;
	private String threadName;
	boolean bisGridFS;
	
	MultiThreadedJava(String tName, boolean bGridFS) {
		
		threadName = tName;
		bisGridFS = bGridFS;
		//System.out.println("Creating Thread " + threadName );
	
	}
	
	// This function will start the thread
	public void start() {
		
		//System.out.println("Starting " +  threadName );
	      if (t == null)
	      {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	}
	
	public void run() {
		
		// This will intiatiate the call for the copy of the document either using GridFS or directly inserting them in BSON format
		// Remember that the BSON document limit is 16 MB
		// For GRIDFS, there is no limit on the size, As per Mongodb website even 100 MB files are stored in the database using the GRIDFS file system.
		Logger logger1 = Logger.getLogger(MultiThreadedJava.class.getName());
		
		if (bisGridFS) {
			DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date1 = new Date();
			logger1.info("Thread: " +  threadName + " started @ " + dateFormat1.format(date1));
			for ( int i =0; i < 10 ; ++i ) {
			
				InsertFileUsingGridFsInMongoDb gridfs = new InsertFileUsingGridFsInMongoDb();
				long millisBefore = System.currentTimeMillis();				
				gridfs.SaveDocument();			
				long millisAfter = System.currentTimeMillis();
				logger1.info("Thread: " +  threadName + "took " + (millisAfter - millisBefore) + " time for iteration" + i);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			logger1.info("Thread: " +  threadName + " finished @ " + dateFormat.format(date));
		} // End of GridFS
		else {
			DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date1 = new Date();
			logger1.info("Thread: " +  threadName + " started @ " + dateFormat1.format(date1));
			for ( int i =0; i < 10 ; ++i ) {
				
				InsertFilesUsingBsonFormat gridfs = new InsertFilesUsingBsonFormat();
				long millisBefore = System.currentTimeMillis();				
				gridfs.SaveDocument();			
				long millisAfter = System.currentTimeMillis();
				logger1.info("Thread: " +  threadName + " took " + (millisAfter - millisBefore) + " time for iteration " + i);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			logger1.info("Thread: " +  threadName + " finished @ " + dateFormat.format(date));
			
		}
						
	}
	
	
	

}
