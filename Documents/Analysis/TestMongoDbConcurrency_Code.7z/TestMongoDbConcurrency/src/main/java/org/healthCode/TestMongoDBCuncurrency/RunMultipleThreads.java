package org.healthCode.TestMongoDBCuncurrency;

import org.apache.log4j.Logger;

public class RunMultipleThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// GridFS testing
		
/*		for ( int i = 0; i< 10; i++ ) {

			String threadName = "Thread" + String.valueOf(i);
			MultiThreadedJava thread1 = new MultiThreadedJava(threadName,true);
			thread1.start();					
		}
*/		
		for ( int i = 0; i< 10; i++ ) {

			String threadName = "Thread" + String.valueOf(i);
			MultiThreadedJava thread1 = new MultiThreadedJava(threadName,false);
			thread1.start();					
		}
	
}
	
}
